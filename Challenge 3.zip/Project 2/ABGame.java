import java.io.*;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class ABGame {

    public static int positionsEvaluated = 0;
    public static int estimate = 0;
    public static int minWorst = 1000000;
    public static int maxWorst = -1000000;

    public static void main(String[] args) {
        try {
            if (args.length != 3) {
                System.out.println("Usage: ABGame <inputfile> <outputfile> <depth>");
                System.exit(1);
            }

            String inputFile = args[0];
            String outputFile = args[1];
            int depth = Integer.parseInt(args[2]);

            char[] board = readBoardFromFile(inputFile);
            char[] newBoard = ABGamePlay(board, depth);

            writeBoardToFile(outputFile, newBoard);

            System.out.println("Input position: " + Arrays.toString(board)
                    + "\nOutput Position: " + Arrays.toString(newBoard)
                    + "\nPositions Evaluated by Static Estimation: " + positionsEvaluated
                    + "\nAlpha-Beta Game estimate: " + estimate);

            System.out.println("The Alpha-Beta algorithm was executed successfully.");
        } catch (IOException | NumberFormatException e) {
            handleException(e);
        }
    }

    private static char[] readBoardFromFile(String filePath) throws IOException {
        StringBuilder boardString = new StringBuilder();
        File file = new File(filePath);

        try (Scanner scanner = new Scanner(file)) {
            if (!scanner.hasNext()) {
                throw new IOException("There is nothing in the file");
            }

            String line = scanner.nextLine();
            for (char c : line.toCharArray()) {
                if (c != 'W' && c != 'x' && c != 'B') {
                    throw new IOException("The only allowed characters are W, x, B in the file");
                } else {
                    boardString.append(c);
                }
            }
        }

        if (boardString.length() != 23) {
            throw new IOException("There must be exactly 23 positions, but you had " + boardString.length());
        }

        return boardString.toString().toCharArray();
    }

    private static void writeBoardToFile(String filePath, char[] board) throws IOException {
        String content = new String(board);
        try (FileWriter file = new FileWriter(new File(filePath))) {
            file.write(content);
        }
    }

    private static char[] ABGamePlay(char[] board, int depth) {
        Game game = new Game(board);
        char[] newBoard = AB(game, board, depth, true, maxWorst, minWorst);
        estimate = game.staticEstimationMidgameEndgame(newBoard);
        return newBoard;
    }

    private static char[] AB(Game game, char[] board, int depth, boolean maxPlayer, int alpha, int beta) {
        if (depth == 0) {
            positionsEvaluated++;
            return board;
        }

        List<char[]> childBoards = maxPlayer ? game.generateMovesMidgameEndgame(board) : game.generateBlackMoves(board);
        char[] bestBoard = null;

        for (char[] child : childBoards) {
            char[] result = AB(game, child, depth - 1, !maxPlayer, alpha, beta);
            int childScore = game.staticEstimationMidgameEndgame(result);

            if (maxPlayer) {
                if (childScore > alpha) {
                    alpha = childScore;
                    bestBoard = child;

                    if (alpha >= beta) {
                        break;
                    }
                }
            } else {
                if (childScore < beta) {
                    beta = childScore;
                    bestBoard = child;

                    if (alpha >= beta) {
                        break;
                    }
                }
            }
        }

        if (bestBoard == null) {
            return board;
        }

        return bestBoard;
    }

    private static void handleException(Exception e) {
        System.err.println("An error occurred: " + e.getMessage());
        e.printStackTrace();
    }
}


