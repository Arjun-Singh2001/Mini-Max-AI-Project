import java.io.*;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class MiniMaxGame {

    public static int positionsEvaluated = 0;
    public static int estimate = 0;
    public static int minWorst = 1000000;
    public static int maxWorst = -1000000;

    public static void main(String[] args) {
        try {
            if (args.length != 3) {
                System.out.println("Usage: MiniMaxGame <inputfile> <outputfile> <depth>");
                System.exit(1);
            }

            String inputFile = args[0];
            String outputFile = args[1];
            int depth = Integer.parseInt(args[2]);

            char[] board = readBoardFromFile(inputFile);
            char[] newBoard = minimaxGame(board, depth);

            writeBoardToFile(outputFile, newBoard);

            System.out.println("Input position: " + Arrays.toString(board)
                    + "\nOutput Position: " + Arrays.toString(newBoard)
                    + "\nPositions Evaluated by Static Estimation: " + positionsEvaluated
                    + "\nMINIMAXGame estimate: " + estimate);

            System.out.println("The MiniMax algorithm was executed successfully.");
        } catch (IOException | NumberFormatException e) {
            handleException(e);
        }
    }

    private static char[] readBoardFromFile(String filePath) throws IOException {
        StringBuilder boardString = new StringBuilder();
        File file = new File(filePath);

        try (Scanner scanner = new Scanner(file)) {
            if (!scanner.hasNext()) {
                throw new IOException("There is nothing in the file");
            }

            String line = scanner.nextLine();
            for (char c : line.toCharArray()) {
                if (c != 'W' && c != 'x' && c != 'B') {
                    throw new IOException("The only allowed characters are W, x, B in the file");
                } else {
                    boardString.append(c);
                }
            }
        }

        if (boardString.length() != 23) {
            throw new IOException("There must be exactly 23 positions, but you had " + boardString.length());
        }

        return boardString.toString().toCharArray();
    }

    private static void writeBoardToFile(String filePath, char[] board) throws IOException {
        String content = new String(board);
        try (FileWriter file = new FileWriter(new File(filePath))) {
            file.write(content);
        }
    }

    private static char[] minimaxGame(char[] board, int depth) {
        Game game = new Game(board);
        char[] newBoard = miniMax(game, board, depth, true);
        estimate = game.staticEstimationMidgameEndgame(newBoard);
        return newBoard;
    }

    private static char[] miniMax(Game game, char[] board, int depth, boolean maxPlayer) {
        if (depth == 0) {
            positionsEvaluated += 1;
            return board;
        }

        List<char[]> childBoards = maxPlayer ? game.generateMovesMidgameEndgame(board) : game.generateBlackMoves(board);
        char[] bestBoard = null;
        int bestScore = maxPlayer ? maxWorst : minWorst;

        for (char[] child : childBoards) {
            char[] result = miniMax(game, child, depth - 1, !maxPlayer);
            int childScore = game.staticEstimationMidgameEndgame(result);

            if ((maxPlayer && childScore > bestScore) || (!maxPlayer && childScore < bestScore)) {
                bestBoard = child;
                bestScore = childScore;
            }
        }

        if (bestBoard == null) {
            return board;
        }

        return bestBoard;
    }

    private static void handleException(Exception e) {
        System.err.println("An error occurred: " + e.getMessage());
        e.printStackTrace();
    }
}

